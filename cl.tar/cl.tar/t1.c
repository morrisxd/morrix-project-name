typedef unsigned short int ushort_t;

typedef int (*pFun)(int);

ushort_t us_pm;

int ffuuu ( int n)
{
	int i = 0;
	return 3;
}


